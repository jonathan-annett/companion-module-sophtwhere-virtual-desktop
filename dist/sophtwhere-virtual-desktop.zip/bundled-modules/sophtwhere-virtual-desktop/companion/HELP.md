## sophtwhere-virtual-desktop

virtual desktop switching for windows 10 and 11.

Should not require any setup, however it does depend on microsoft.net, which is normally included in windows 10 and 11

actions include

goto desktop
    switch to a desktop by index, or name

next desktop
    increment the desktop index 

previous desktop
    decrement the desktop index 


variables

count
    the number of desktops
visibleIndex
visible