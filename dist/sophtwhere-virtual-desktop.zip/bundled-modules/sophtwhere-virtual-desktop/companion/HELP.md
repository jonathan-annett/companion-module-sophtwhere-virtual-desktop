## sophtwhere-virtual-desktop

virtual desktop switching for windows 10 and 11.

Should not require any setup, however it does depend on microsoft.net, which is normally included in windows 10 and 11

if for some reason it fails to select